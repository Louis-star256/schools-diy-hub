# 🚀 Hosting School's DIY Hub on schoolsdiyhub.com (Ultimate Connection Guide)

Follow these exact steps to bridge your project from Firebase Studio to your new domain and activate the **Real Money Venture System**.

## 1. 📂 Export Your Code (WHAT HAPPENS AFTER YOU CLICK ZIP)
1. **The ZIP Download**: After clicking **"Zip and Download"**, a file named `School's DIY Hub.zip` will download to your computer.
2. **Locate & Extract**: Find the file in your "Downloads" folder. **Right-click it** and select **"Extract All..."** or **"Unzip"**. This creates a folder with your app's code.

## 2. 🌐 Upload to GitHub (Your Storage Node)
1. Open [GitHub](https://github.com/) and log in.
2. Click **"New"** to create a repository. Name it `schools-diy-hub`.
3. Select **"Upload an existing file"**.
4. **Drag and drop ALL the files** from the extracted ZIP folder into the GitHub box.
5. Click **"Commit changes"** at the bottom.

## 3. 🔗 Connect Vercel to GitHub
1. In your **Vercel Dashboard**, click **"Add New..."** > **"Project"**.
2. Find your `schools-diy-hub` repository and click **"Import"**.
3. Under **Environment Variables**, add these keys (Copy them carefully):

| Key | Value |
| :--- | :--- |
| `GEMINI_API_KEY` | `AIzaSyDIzE-fwTT-5kZ31qcTl34UmwQLhZj2Fwk` |
| `NEXT_PUBLIC_FIREBASE_API_KEY` | `AIzaSyDIzE-fwTT-5kZ31qcTl34UmwQLhZj2Fwk` |
| `NEXT_PUBLIC_FIREBASE_PROJECT_ID` | `studio-1216835987-c72bd` |

4. Click **"Deploy"**.

## 4. 🔗 Link Your Domain
1. Once deployed, go to the project in Vercel.
2. Go to **Settings > Domains**.
3. Type `schoolsdiyhub.com` and click **Add**. Vercel will handle the SSL security automatically.

## 5. 🔐 Authentication Setup (FIXES LOGIN ERROR - DO NOT SKIP)
**If you do not do this, your website will fail to log users in:**
1. Go to your [Firebase Console > Authentication > Settings](https://console.firebase.google.com/project/studio-1216835987-c72bd/authentication/settings).
2. Click the **"Authorized domains"** tab.
3. Click **"Add domain"**.
4. Paste `schoolsdiyhub.com` and click **Add**.
5. Also add `www.schoolsdiyhub.com` to be safe.

## 🛰️ Set IPN Listener URL
In your **PesaPal Merchant Dashboard**, set the **IPN Listener URL** so you can receive money:
- **IPN URL**: `https://schoolsdiyhub.com/api/ipn`
- **Method**: `GET`
