# **App Name**: School's DIY Hub

## Core Features:

- Project Ideas: Suggest DIY project ideas based on available materials and skill level, complete with step-by-step instructions.
- Material Sourcing: Provide a list of common materials needed for school DIY projects and suggest easily accessible sources.
- Skill Level Filter: Allow users to filter projects based on skill level (beginner, intermediate, advanced).
- Step-by-Step Guide: Provide clear, easy-to-follow instructions, possibly with image and video integration, for each project. Leverage AI tool to suggest simplifications
- School Login: Schools should log in with their email accounts and fall under these categories: Primary Institution/Secondary Institution/Tertiary Institution. Under the school's account, students should also have their own accounts but under the school's
- Student Project Showcase: Students should be able to post their project work (ICT & science projects) on their account which must be public and accessible by any person who would wish to visit that particular person's work. The items posted should be in form of videos, pictures, write ups or even links in case their project is accessible by a link. The more items a student posts on his /her account the more stars he gets meaning he can attract more viewer to his site and also the more likes the audience credits that person.
- Chat Feature: People should also be allowed to chat with their friends they see or meet on this web site
- Feedback Feature: People should also be able to send feed back to me so that I can know what I can update on my web site
- Individual Sign-in: Individuals can also sign in with their own person email accounts (no part of an institution) and benefit like others
- Personal Information: On each person's account, there should be part of his /her personal information for instance, a pass port picture, full name, home address, level of studies, personal contacts, why he is interested in innovation skills plus others.and all this information must be public
- Language choice: the main language used should be according to the individual's choice/institution.the audience should recevice messages or see other information on their account according to the choice of language chosen.languages should only be international languages.this is to favour all kinds of countries that may be interested in using this wed site
- Search Bar: there should be a search bar to easily access information on this wed site like looking for someones account
- About Me: Space to write about me, my contacts, and services this site will be offering

## Style Guidelines:

- Primary color: Vibrant blue (#29ABE2), reminiscent of school supplies and creativity.
- Background color: Light blue (#E0F7FA), providing a calm and clean backdrop.
- Accent color: Yellow (#FFDA63), to highlight key actions and call attention to details.
- Body and headline font: 'Inter', a sans-serif, providing a modern and easily readable typeface suitable for all ages.
- Use playful, illustrative icons relevant to school, craft, and DIY themes.
- Clean and organized layout with clear sections for browsing projects, viewing instructions, and filtering options.
- Subtle animations to guide users through steps, such as highlighting key components or providing interactive feedback.